Max Gains V5.3 — Journal cloud synchronization fix.
Previously synced journal entries deleted from Supabase are removed from local app storage on successful cloud refresh. Pending unsynced entries are retained and retried. Known test IDs blocked from reupload. No schema changes.
